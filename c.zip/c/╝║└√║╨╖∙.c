#include <stdio.h>
#include <string.h>
#include <malloc.h>

typedef struct _student {
	char *name;
	int kor;
	int eng;
	int math;
	int total;
	double ave;
} Student;

void printStudent(Student *p[], int n)
{ 
	int i;
	
	printf(" �̸�    ����   ����   ����  �հ�  ���\n");
	
	for (i = 0; i < n; i++) {
		printf("%7s%8d%8d%8d%8d%8.1f\n",
			p[i]->name,p[i]->kor,p[i]->eng,p[i]->math,p[i]->total,p[i]->ave);
	}
	printf("=========================================\n");
}

void sortByName(Student *p[], int n) 
{
	int i, j;
	 for(i = 0; i < n-1; i++) {
	 	for (j = 0; j < n-i-1; j++) {
	 		if(strcmp(p[j]->name,p[j+1]->name) > 0) {
	 			Student *tmp;
	 			
	 			tmp = p[j];
	 			p[j] = p[j+1];
	 			p[j+1] = tmp;
			 }
		 }
	 }
}

void sortByTotal(Student *p[], int n)
{
	int i, j;
	
	for (i = 0; i < n-1; i++) {
		for (j = 0; j < n-i-1; j++) {
			if (p[j]->total > p[j+1]->total) {
				Student *tmp;
				
				tmp = p[j];
				p[j]= p[j+1];
				p[j+1]= tmp;
			}
		}
	}
}

main()
{
	Student **s;
	FILE *inFile;
	int n;
	int i;
	
	fopen_s(&inFile, "data.txt", "r");
	
	fscanf_s(inFile,"%d",&n);
	
	s = (Student **)malloc(n*sizeof(Student*));
	
	for (i = 0; i < n; i++) {
		char buffer[BUFSIZ];
		int kor, eng, math;
		
		fscanf_s(inFile, "%s %d %d %d",
			buffer,BUFSIZ,&kor,&eng,&math);
			
		s[i] = (Student *)malloc(sizeof(Student));
		s[i]->name = _strdup(buffer);
		s[i]->kor = kor;
		s[i]->eng = eng;
		s[i]->math = math;
	}
	
	for(i = 0; i < n; i++) {
		s[i]->total = s[i]->kor + s[i]->eng + s[i]->math;
		s[i]->ave = s[i]->total/3.0;
	}
	
	printStudent(s,n);
	
	fclose(inFile);
	
	sortByTotal(s,n);
	
	printStudent(s,n);
	
	sortByName(s,n);
	
	printStudent(s,n);
}
