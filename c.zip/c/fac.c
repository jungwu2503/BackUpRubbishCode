#include <stdio.h>

int factorial(int n)
{
	if (n == 0) return 1;
	n = n * factorial(n - 1);
	return n;
}


main()
{
	int n;
	int ans;
	
	scanf("%d", &n);
	
	ans = factorial(n);
	printf("%d", ans);
}

