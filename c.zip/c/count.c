#include <stdio.h>

main()
{
	int i, j;
	int n;
	int cnti, cntj = 1;
	int cnt = 0;
	int some;
	
	scanf("%d", &n);
	
	for (i = 1; i <= n; i++) {
		if (cnt % 2 == 0) {
			for (j = 1; j <= cnt; j++) {
				some = i + 1;
				cnti++;
				if (some > cnti) {
					cntj = some - cnti;
				} else {
					cntj = cnti - some;
				}
			}
		} else if (cnt % 2 == 1) {
			for (j = 1; j <= cnt; j++) {
				some = i + 1;
				cnti--;
				if (some > cnti) {
					cntj = some - cnti;
				} else {
					cntj = cnti - some;
				}
			}
		}		
		cnt++;
	}
	
	printf("%d IS %d/%d", n, cnti, cntj);

}
/*
i 
	1  1 2  3 2 1  1 2 3 4  5 4 3 2 1
j
	1  2 1  1 2 3  4 3 2 1  1 2 3 4 5
*/
