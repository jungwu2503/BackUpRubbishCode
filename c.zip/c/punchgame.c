#include <stdio.h>

main()
{
	int p[5];
	int i;
	int totalpunch = 0;
	int damage = 0;
	int game[5] = { 10, 15, 30, 40, 45};
	
	for(i = 0; i < 5; i++) {
		scanf("%d", &p[i]);
		totalpunch += p[i];
	}
		
	if (totalpunch > 10) {
		printf("time out");	
	} else {
		for (i = 0; i < 5; i++) {
			damage = damage + (p[i] * game[i]);
		}
		if (damage >= 100) printf("you win");
		else printf("game over");
	}
	
}
