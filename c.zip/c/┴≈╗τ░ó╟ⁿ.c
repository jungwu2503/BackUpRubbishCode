#include <stdio.h>

main()
{
	int a, b, c, d;
	int x, y, p, q;
	
	scanf("%d %d %d %d", &a, &b, &c, &d);
	scanf("%d %d %d %d", &x, &y, &p, &q);
	
	if (a > p || c < x || b > q || d < y) {
		printf("none");
	} else if (a >= p || c <= x || b >= q || d <= y) {
		printf("line");
	} else if (b == q && c == x || c == x && d == y || p == a && y == d || p == a && q == b) {
		printf("point");
	} else {
		printf("rectangle");
	}
	
}
