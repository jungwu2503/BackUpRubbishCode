#include <stdio.h>

main()
{
	int black, white = 0;
	
	scanf("%d %d", &black, &white);
		
	if (white % 2 != 0 && black % 2 != 0) printf("white");
	else if (white % 2 == 0 && black % 2 == 0) printf("black");
	else if (white % 2 == 0 && black % 2 != 0) printf("black");
	else printf("white");
	
}
