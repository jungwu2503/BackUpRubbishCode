#include <stdio.h>

main()
{
	int n;
	int i;
	int floor = 1;
	
	scanf("%d", &n);
	
	for (i = 0; i < n; i++) {
		floor = floor * 2;
		if (n < floor) {
			printf("%d", i+1);
			break;
		}
	}
	
	/*
	0 - 1
	1 - 2
	2 - 4
	3 - 8
	4 - 16
	5 - 32
		*/
}
