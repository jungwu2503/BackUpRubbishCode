#include <stdio.h>

main()
{
	int arr[8];
	int i;
	int n=0;
	int m=0;
	int asc[8] = { 1, 2, 3, 4, 5, 6, 7, 8};
	int des[8] = { 8, 7, 6, 5, 4, 3, 2, 1};
	
	for (i = 0; i < 8; i++) {
		scanf("%d", &arr[i]);
	}
	
	for (i = 0; i < 8; i++) {
		if (arr[i] == asc[i]) {
			n++;
//			printf("ascending\n");
		} else if (arr[i] == des[i]) {
			m++;
//			printf("descending\n");
		}
	}
	
	if (n == 8) printf("ascending");
	else if (m == 8) printf("descending");
	else printf("mixed");
	
}
