#include <stdio.h>

main()
{
	int n;
	int i;
	
	scanf("%d", &n);
	
	for(i = n; i >= 1; i--)	{
		if (n % i == 0) printf("%d\n", n/i);
	}
	
}
