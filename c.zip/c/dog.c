#include <stdio.h>
#define safe 0
#define attack 1

main()
{
	int a, b, c, d, p, m, g;
	int doga, dogb = 0;
	int i;
	
	scanf("%d%d%d%d%d%d%d", &a,&b,&c,&d,&p,&m,&g);
	
	if (p <= a) {doga = safe;}
	else if (p >= a && p <= a+b) {doga = attack;}
	if (p <= c)	{dogb = safe;}
	else if (p >= c && p <= c+d) {dogb = attack;}
	if (doga == attack && dogb == attack) {printf("none\n");}
	else if (doga == attack || dogb == attack) { printf("one\n");}
	else {printf("both\n");}
	
	if (m <= a) {doga = safe;}
	else if (m >= a && m <= a+b) {doga = attack;}
	if (m <= c)	{dogb = safe;}
	else if (m >= c && m <= c+d) {dogb = attack;}
	if (doga == attack && dogb == attack) {printf("none\n");}
	else if (doga == attack || dogb == attack) { printf("one\n");}
	else {printf("both\n");}
	
	if (g <= a) {doga = safe;}
	else if (g >= a && g <= a+b) {doga = attack;}
	if (g <= c)	{dogb = safe;}
	else if (g >= c && g <= c+d) {dogb = attack;}
	if (doga == attack && dogb == attack) {printf("none\n");}
	else if (doga == attack || dogb == attack) { printf("one\n");}
	else {printf("both\n");}
	
}
