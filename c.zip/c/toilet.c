#include <stdio.h>

main()
{
	int m;
	int i;
	int max = 0;
	int min = 1;
	
	scanf("%d", &m);
	
	max = m / 2 + 1;
	
	if (m % 2 == 0)
		min = (m - 1) / 2;
	else  {
		if (m <= 7)
			min = m / 2;
		else
			min = m / 2 - 1;
	}
	if (m == 1) min = 1;
	
	printf("%d %d", max, min);
	
}
