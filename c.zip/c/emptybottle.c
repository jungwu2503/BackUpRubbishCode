#include <stdio.h>

main()
{
	int bottle;
	int bottle2 = 0;
	int bottle3 = 0;
	int empty = 0;
	int total = 0;
	
	scanf("%d", &bottle);
	
	bottle2 = bottle/4;
	bottle3 = bottle2/4;
	
	total = bottle + bottle2 + bottle3;
	
	empty = (bottle % 4) + (bottle2 % 4);
	
	printf("%d %d", total, empty);
	
}
