#include <stdio.h>

main()
{
	int i, j;
	int n;
	
	scanf("%d", &n);
	
	for(i = 1; i <= n; i++) {
		for(j = 0; j < i-1; j++) {
			printf(" ");
		}
		for(j = 0; j < n+1-i; j++) {
			printf("*");
		}
		for(j = 0; j < n-i; j++) {
			printf("*");
		}
//		for(j = 0; j < i; j++) {
//			printf(" ");
//		}
		printf("\n");
	}
	
	for(i = 1; i <= n-1; i++) {
		for(j = 0; j < n-i-1; j++) {
			printf(" ");
		}
		for(j = 0; j < i+1; j++) {
			printf("*");
		}
		for(j = 0; j < i; j++) {
			printf("*");
		}
//		for(j = 0; j < n-i-1; j++) {
//			printf(" ");
//		}
		
		printf("\n");	
	}
	
 
	
}
