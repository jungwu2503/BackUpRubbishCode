#include <stdio.h>
#include <string.h>

main()
{
	int i, j;
	char word[101];
	int size;
	int tmp;
	int arr[26];
	int max = 0;
	int count = 0;
	int idx;
	
	scanf("%s", word);
	
	for (i = 0; word[i] != '\0' ; i++) {
		if (word[i] >= 'a' && word[i] <= 'z') {
			idx = word[i] - 'a';
		} else if (word[i] >= 'A' && word[i] <= 'Z') {
			idx = word[i] - 'A';
		}
		arr[idx]++;
	} 
	
	for (i = 0; i < 26; i++) {
		if (arr[i] > max) {
			max = arr[i];
			tmp = i;
		}
	}
	
	for (i = 0; i < 26; i++) {
		if (max == arr[i]) count++;
	}
	
	if (count >= 2) printf("?");
	else printf("%c", tmp);
	
}
