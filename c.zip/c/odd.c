#include <stdio.h>

main()
{
	int arr[8] = {0};
	int i;
	
	for (i = 0; i < 7; i++) {
		scanf("%d", &arr[i]);
	}
	
	for (i = 0; i < 7; i++) {
		printf("%d ", arr[i]);
	}
	
}
