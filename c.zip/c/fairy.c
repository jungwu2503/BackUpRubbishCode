#include <stdio.h>

main()
{
	int year = 2000;
	int i;
	int n;
	
	scanf("%d", &n);
	
	n = n - 2000;
	
	if (n >= 0) {
		if (n % 8 == 0) printf("O");
		else printf("X");
	}
	else printf("X");
	
}
