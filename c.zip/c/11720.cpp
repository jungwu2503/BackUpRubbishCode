#include <stdio.h>
#include <string.h>

main()
{
	int i, j;
	char s[101];
	int buf[26];
	int asc[26];
	int min = 97;
	int size;
	
	scanf("%s", s);
	size = strlen(s);
	
	for (i = 0; i < 26; i++) {
		asc[i] = i + 'a';
		buf[i] = -1;
	}	
	
	for (i = 0; i < size; i++) {
		for (j = 0; j < 26; j++) {
			if (s[i] == asc[j] && buf[j] == -1)
				buf[j] = i;
		}
	}
	
	for (i = 0; i < 26; i++) {
		printf("%d ", buf[i]);
	}
	
	
}
