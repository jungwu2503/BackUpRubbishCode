#include <stdio.h>

main()
{
	int a, b, c, d;
	int e, f;
	
	scanf("%d %d %d %d", &a, &b, &c, &d);
	
	if (b - a == d - c) {
		e = d + d - c;
		printf("%d %d %d %d %d", a, b, c, d, e);	
	}
	else if (b / a == d / c) {
		f = d * (d / c);
		printf("%d %d %d %d %d", a, b, c, d, f);
	}

}
