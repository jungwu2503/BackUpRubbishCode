#include <stdio.h>

main()
{
	int k, n;
	
	scanf("%d %d", &k, &n);
	
 	printf("%d", (n-1)*(k-1)*100);
	
	
}
