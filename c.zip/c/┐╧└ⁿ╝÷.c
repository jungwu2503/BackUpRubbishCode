#include <stdio.h>

main()
{
	int n;
	int i;
	int count = 0;
	
	scanf("%d", &n);
	
	for (i = 1; i <= n; i++) {
		if(n % i == 0) {
			count = count + n / i;
		}
	}
	count = count - n;
	
	if (count == n) {
		printf("%5d  perfect", n);
	} else if (count > n) {
		printf("%5d  abundant", n);
	} else if (count < n) {
		printf("%5d  deficient", n);
	}
	
}
