#include <stdio.h>
#include <string.h>

main()
{
	char a1[5], a2[5], s1[5], s2[5];
	int i, j;
	int count = 0;
	
	scanf("%s", &a1);
	
	strcpy(a2, a1);
	
	for (j = 0; j < 10; j++) {
		for (i = 0; i < 4; i++) {
			if (a1[i] < a1[i+1]) {
				s1[i] = a1[i];
				a1[i] = a1[i+1];
				a1[i+1] = s1[i];
			}
			if (a2[i] < a2[i+1]) {
				s2[i] = a2[i];
				a2[i] = a2[i+1];
				a2[i+1] = s2[i];
			}
		} 
		
		for (i = 0; i < 4; i++) {
			s1[i] = a1[i] - a2[i];
		}
		for (i = 0; i < 4; i++) {
			a1[i] = s1[i]; 
		}
		count++;
		if (a1[0] == '6' && a1[1] == '1' && a1[2] == '7' && a1[3] == '4') break;
	}
	printf("%d", count);
}
