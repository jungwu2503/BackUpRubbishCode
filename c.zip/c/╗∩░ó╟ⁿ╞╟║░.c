#include <stdio.h>

main()
{
	int a, b, c;
	int max;
	int o1, o2;
	
	scanf("%d %d %d", &a, &b, &c);
	
	if (a >= b && a >= c) {
		max = a;
		o1 = b;
		o2 = c;
	} else if (b >= a && b >= c) {
		max = b;
		o1 = a;
		o2 = c;
	} else {
		max = c;
		o1 = a;
		o2 = b;
	}
	
	if (max * max == o1 * o1 + o2 * o2) {
		printf("right");
	} else if (max * max > o1 * o1 + o2 * o2) {
		printf("obtuse");
	} else {
		printf("acute");
	}
}
