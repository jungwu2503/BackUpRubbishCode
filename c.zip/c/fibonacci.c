#include <stdio.h>

int fibo(int n)
{
	int sum = 0;
	
	if (n == 0) return 0;
	if (n == 1) return 1;
	
	return fibo(n-2) + fibo(n-1);
	
}

main()
{
	int n;
	int ans = 0;
	
	scanf("%d", &n);
	
	ans = fibo(n);
	printf("%d", ans);
	
}

