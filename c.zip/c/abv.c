#include <stdio.h>

main()
{
	int a, b, v;
	int total = 0;
	
	scanf("%d %d %d", &a, &b, &v);

	if ((v-b) % (a-b) == 0)	total = (v-b)/(a-b);
	else total = (v-b) / (a-b) + 1;
	
	printf("%d", total);
}
