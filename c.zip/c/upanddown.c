#include <stdio.h>

main()
{
	int a, b, c, d = 0;
	int i, j, s;
	int nik, by = 0;
	int count = 0;
	
	scanf("%d %d %d %d %d", &a, &b, &c, &d, &s);
	
	for (i = 1; i <= s; i++) {
		for (j = 1; j <= a; j++) {
			nik++;
			count++;
		}
		for (j = 1; j <= b; j++) {
			nik--;
			count++;
		}
		if (count == s) break;
	}
	
	count = 0;
	
	for (i = 1; i <= s; i++) {
		
			for (j = 1; j <= c; j++) {
				by++;
				count++;
			}
			for (j = 1; j <= d; j++) {
				by--;
				count++;
			}
		
	}
	
	printf("%d %d", nik, by);

	
	
}
