#include <stdio.h>

int fibo(int n, int *countzero, int *countone)
{
	if (n == 0) {
		countzero++;
		return 0;	
	}	
	if (n == 1) {
		countone++;
		return 1;
	}
	if (n == 2) countone++;
	else return fibo(n-1, countzero, countone) + fibo(n-2, countzero, countone);
}

main()
{
	int i, n;
	int num;
	int countzero, countone = 0;
	
	scanf("%d", &n);
	
	for (i = 0; i < n; i++) {
		scanf("%d", &num);
		fibo(num, &countzero, &countone);
		printf("%d %d\0", countzero, countone);
	}
	
}
