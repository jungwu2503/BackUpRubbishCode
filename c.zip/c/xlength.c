#include <stdio.h>
#include <math.h>

main()
{
	int a, b;
	double ans;
	double a1, b1;
	double a2, b2;

	scanf("%d %d", &a, &b);
	
	a1 = a * 3.14159;
	b1 = b * 3.14159;
	
	a2 = sqrt(2) * a;
	b2 = sqrt(2) * b;
	
	ans = a1 + a2 + b1 + b2;
	
	printf("%.3f", ans);

}
