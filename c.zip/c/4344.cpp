#include <stdio.h>

main()
{
	int student = 0;
	int i, j, n;
	int score[10];
	int average = 0;
	
	
	scanf("%d", &student);
	
	for(i = 0; i < student; i++) {
		scanf("%d", &n);
		for(j = 0; j < n; j++) {
			scanf("%d", &score[j]);
			average = average + score[j];
		}
		average/n;
	}
	
}
