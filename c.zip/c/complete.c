#include <stdio.h>

main()
{
	int n;
	int i;
	int sum = 0;
	
	scanf("%d", &n);
	
	for (i = 1; i <= n; i++) {
		if (i != 1 && n % i == 0) sum = sum + n / i;
	}
	if (sum == n) printf("yes");
	else printf("no");
	
}
