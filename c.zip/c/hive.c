#include <stdio.h>

main()
{
	int n;
	int count = 1;
	int sum = 0;
	int i;
	
	scanf("%d", &n);
	
	if (n == 1) count = 1;
	else {
		for (i = 1; ; i++) {
			sum = sum + 6 * i;
			if (n <= sum + 1) {
				count++;
				break;
			} else count++;
		}
	}
	printf("%d", count);
}

/*
1
2-7 6
8-19 12
20-37 18
38-61
*/
