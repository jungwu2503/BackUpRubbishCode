#include <stdio.h>

main()
{
	int n;
	int i;
	double per = 1;
	
	scanf("%d", &n);
	
	for(i = 0; i < n; i++) {
		per = (double)per/365;
	}
	
	printf("%lf", per);
	
}
