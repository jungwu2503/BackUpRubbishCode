#include <stdio.h>

main()
{
	int ans = 0;
	int n;
	
	scanf("%d", &n);
	
	if (n >= 10) {
		if (n % 5 == 0) {
			ans = n / 5;
		} else if (n % 5 == 3) {
			ans = n / 5 + 1;
		} else if (n % 5 == 2) {
			ans = (n-12)/5 + 12/3;
		} else if (n % 5 == 1) {
			ans = (n-6)/5 + 6/3;
		} else {
			ans = -1;
		}
	} else {
		if (n == 0) ans = -1;
		else if (n % 5 == 0) ans = 1;
		else if (n % 5 == 3) ans = 2;
		else if (n % 3 == 0) ans = n/3;
		else ans = -1;
	}

	printf("%d", ans);
	
}



/*
main()
{
	int a, b, v;
	int i;
	int total = 0;
	int count = 0;
	
	scanf("%d %d %d", &a, &b, &v);
	
	for (i = 0; i < v; i++) {
		total = total + a;
		count++;
		if (total >= v) break;
		else total = total - b;
	}
	printf("%d", count);
	
}
*/
