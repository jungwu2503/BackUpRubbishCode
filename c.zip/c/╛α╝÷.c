#include <stdio.h>

main()
{
	int n, k;
	int i;
	int yaksu[10001];
	
	scanf("%d %d", &n, &k);
	
	for (i = 1; i <= n; i++) {
		if (n % i == 0) {
			yaksu[i-1] = i;
		}
		if (i == k) {
			printf("%d ", yaksu[i-1]);
		}
	}
	
}
