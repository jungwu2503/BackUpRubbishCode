#include <stdio.h>
#include <string.h>

main()
{
	char a;
	
	scanf("%c", &a);
	printf("%d", a);
	
}
