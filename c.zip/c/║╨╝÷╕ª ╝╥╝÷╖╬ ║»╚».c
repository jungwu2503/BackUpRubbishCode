#include <stdio.h>

main()
{
	int x, y;
	int z;
	int i;
	
	scanf("%d %d %d", &x, &y, &z);
	
	printf("0.");
	x = x * 10;
	for (i = 0; i < z; i++) {
		printf("%d", x/y);
		x = x%y * 10;
	}
}



