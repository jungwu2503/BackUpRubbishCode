#include <stdio.h>

main()
{
	int troy, wood = 0;
	
	scanf("%d %d", &troy, &wood);
	
//	troy 1 - wood 1000
	
	if (wood >= troy * 1000) 
		printf("O");
	else
		printf("X");
	
	
}
