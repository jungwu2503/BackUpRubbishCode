#include <stdio.h>

main()
{
	int n;
	int i;
	int a, b;
	int width, length = 0;
	
	scanf("%d", &n);
	
	if (n == 1) printf("-1");
	else if (n == 2) {
		scanf("%d %d", &a, &b);
		width = a;
		length = b;
		scanf("%d %d", &a, &b);
		if (width > a) width = width - a;
		else width = a - width;
		if (length > b) length = length - b;
		else length = b - length;
		printf("%d", width*length);
	} else if (n == 3) {
		scanf("%d %d", &a, &b);
		width = a;
		length = b;
		scanf("%d %d", &a, &b);
		if (width > a) width = width - a;
		else width = a - width;
		if (length > b) length = length - b;
		else length = b - length;
		scanf("%d %d", &a, &b);
		printf("%d", width*length);
	} else if (n == 4) {
		scanf("%d %d", &a, &b);
		width = a;
		length = b;
		scanf("%d %d", &a, &b);
		if (width > a) width = width - a;
		else width = a - width;
		if (length > b) length = length - b;
		else length = b - length;
		scanf("%d %d", &a, &b);
		scanf("%d %d", &a, &b);
		printf("%d", width*length);
	}
	
	
}
