#include <stdio.h>

main()
{
	int a, b, c, d, t;
	int i;
	int count = 0;
	double arr[4] = {0};
	double max = 0;
	
	scanf("%d %d %d %d", &a, &b, &c, &d);
	
	for (i = 0; i < 5; i++) {
		arr[i] = (double)a / c + b / d;
		t = a;
		a = c;
		c = d;
		d = b;
		b = t;
	}
	
	for (i = 0; i < 5; i++) {
		if (max < arr[i]) {
			max = arr[i];
			count = i;
		}		
	}
	printf("%d", count);
}


