#include <stdio.h>

main()
{
	int n, m;
	int i;
	int sum, count = 0;
	
	scanf("%d", &m);
	
	for(i = 1; i <= m; i++) {
		sum = sum + i;
		count++;
		if(sum >= m) break;
	}
	
	printf("%d", count);
	
} 
