#include <stdio.h>

main()
{
	int i;
	double n;
	double ave = 0.0;
	
	for (i = 0; i < 12; i++) {
		scanf("%lf", &n);
		ave = ave + n;
	}
	ave = ave / 12;
	printf("%.2f", ave);
	
}
