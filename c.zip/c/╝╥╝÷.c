#include <stdio.h>


main()
{
	int n, i, j;
	int num;
	int count = 0;
	int arr[101];
	int result = 1;
	
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		scanf("%d", &arr[i]);
		if (arr[i] != 1) {
			for (j = 2; j < arr[i]; j++) {
				if (arr[i] % j == 0) {
					result = 0;
					break;
				}
			}
			if (result == 1) count++;
			else result = 1;
		}		
	}
	printf("%d", count);
}

	
/*	for (i = 0; i < n; i++) {
		scanf("%d", &num);
		for (j = 2; j < num; j++) {
			if (num % j != 0) {
				arr[j-2] = 0;
			}
		}
		for (j = 0; j < num - 2; j++) {
			if (arr[j] == 0)
		}
		if (num != 1) {
			if (num == 3) count++;
			else if (num % 2 != 0 && num % 3 != 0) {
				count++;
			}		
		}
	
	printf("%d", count);
	
} */
