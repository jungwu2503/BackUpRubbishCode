#include <stdio.h>

main()
{
	int n;
	int i;
	int arr1[1001] = {0, };
	int arr2[1001] = {0, };
	int sum = 0;
	
	scanf("%d", &n);
	
	for (i = 1; i <= n; i++) {
		arr1[i-1] = i*2 - 1;		
//		printf("%d ", arr1[i-1]);
	}
	
	for (i = 1; i <= n; i++) {	
		arr2[i-1] = arr1[n-i];
//		printf("%d ", arr2[i-1]);
	}

	for (i = 0; i < n; i++) {		
		sum = sum + arr1[i] * arr2[i];
	}
	printf("%d", sum);
	
}
