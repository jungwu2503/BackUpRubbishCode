#include <stdio.h>

main()
{
	int a, b, c, d;
	double ans;
	
	scanf("%d %d %d %d", &a, &b, &c, &d);
	
	if (a == c && b == d) {
		printf("many");
	} else if ( (a == c && b != d) || (a != c && b == d) ) {
		printf("none");
	} else {
		if (a > c) {
			ans = (double) (d - b) / (a - c);		
		} else {
			ans = (double) (b - d) / (c - a);	
		}
		printf("%.3f", ans);
	}
	
}
