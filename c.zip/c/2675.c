#include <stdio.h>
#include <string.h>

main()
{
	int n;
	char s[21];
	int i, j, k;
	int t;
	int size;
	
	scanf("%d", &t);
	
	for (i = 0; i < t; i++) {
		scanf("%d", &n);
		scanf("%s", s);
		for (j = 0; s[j] != '\0'; j++) {
			for (k = 0; k < n; k++) {
				printf("%c", s[j]);
			}
		}
		printf("\n");
	}
	
}


