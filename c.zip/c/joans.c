#include <stdio.h>

main()
{
	int line;
	int ans = 0;
	scanf("%d", &line);
	
	ans = ( 3 * line * line + 6 * line - 15 ) / 2;
	
	printf("%d", ans);
}

//(3n^ + 6n - 15) / 2

