#include <stdio.h>

main()
{
	int a, b, c;
	int plus = 0;
	int total = 0;
	int i;
	
	scanf("%d %d %d", &a, &b, &c);
	
	total = a / c;
	plus = (a + b) / c;
	total = plus + (plus / c);
//	total = total + plus;
	
	
	printf("%d", total);
}
