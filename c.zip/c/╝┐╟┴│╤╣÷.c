#include <stdio.h>

int d(int n)
{
	int sum = 0;
	
	sum = n + n%10 + n%100/10 + n%1000/100 + n%10000/1000;
	
	return sum;
	
}

main()
{
	int sum;
	int i;
	int resum = 1;
	for(i = 0; i <= 100; i++) {
		sum = d(resum);
		printf("%d ", sum);
		resum = sum;
	}
}
