// Hanoi.h : main header file for the HANOI application
//

#if !defined(AFX_HANOI_H__9DD076B6_671C_4F60_9006_5F72C17406AF__INCLUDED_)
#define AFX_HANOI_H__9DD076B6_671C_4F60_9006_5F72C17406AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHanoiApp:
// See Hanoi.cpp for the implementation of this class
//

class CHanoiApp : public CWinApp
{
public:
	CHanoiApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHanoiApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHanoiApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HANOI_H__9DD076B6_671C_4F60_9006_5F72C17406AF__INCLUDED_)
