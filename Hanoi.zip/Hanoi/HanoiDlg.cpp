// HanoiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Hanoi.h"
#include "HanoiDlg.h"

#include "TowerSuDlg.h"
#include "Rectangle.h"
#include "RingList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
#define HEIGHT 10

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHanoiDlg dialog

CHanoiDlg::CHanoiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHanoiDlg::IDD, pParent)
{

	m_RingPlacecount = 0;

	top = 0;

	m_FromHeight = 0;
	m_ToHeight = 0;
	m_TempHeight = 0;

 	//{{AFX_DATA_INIT(CHanoiDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

}

void CHanoiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHanoiDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CHanoiDlg, CDialog)
	//{{AFX_MSG_MAP(CHanoiDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_NEXT_BUTTON, OnNextButton)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHanoiDlg message handlers

BOOL CHanoiDlg::OnInitDialog()
{
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHanoiDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHanoiDlg::OnPaint() 
{
	CPaintDC objectDC1(this);
	CDC *pDC=GetDC();
	CDC * pMemDC = new CDC;
	CBitmap* pMap = new CBitmap();
	pMap->LoadBitmap(IDB_BITMAP1);
	pMemDC->CreateCompatibleDC(pDC);
	CBitmap* OldBitmap = (CBitmap*) pMemDC->SelectObject(pMap);
	pDC->BitBlt(50,  100, 150, 150, pMemDC,  0, 0, SRCCOPY);
	pDC->BitBlt(200, 100, 150, 150, pMemDC, 0, 0, SRCCOPY);
	pDC->BitBlt(350, 100, 150, 150, pMemDC, 0, 0, SRCCOPY);
	delete pMemDC->SelectObject(OldBitmap);
	delete pMemDC;
	ReleaseDC(pDC);

	Draw();
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHanoiDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHanoiDlg::OnNextButton() 

{
	/// TODO: Add your control notification handler code here
	RingMove();
}
void CHanoiDlg::Hanoi(int n,char m_from,char m_to,char m_temp)
{
	if ( n == 1 ) {
		m_RingPlace[m_RingPlacecount] = m_from;
			m_RingPlacecount++;
		m_RingPlace[m_RingPlacecount] = m_to;
			m_RingPlacecount++;
		} else {
	Hanoi(n-1, m_from, m_temp, m_to);
	m_RingPlace[m_RingPlacecount] = m_from;
		m_RingPlacecount++;
	m_RingPlace[m_RingPlacecount] = m_to;
		m_RingPlacecount++;
	Hanoi(n-1, m_temp, m_to, m_from);
	}
}

int CHanoiDlg::DoModal(int i) 
{
	m_TowerSu = i;
	// TODO: Add your specialized code here and/or call the base class
	return CDialog::DoModal();
}
void CHanoiDlg::Draw()
{	
	if(top == 0)
	{
		RingMake();
	}
	else
	{
		DrawMove();
	}
}

void CHanoiDlg::RingMake()
{
	int i = 1;
	CPaintDC objectDC1(this);
	CDC *pDC=GetDC();
	CDC * pMemDC = new CDC;
	CBitmap* pMap = new CBitmap();
	pMap->LoadBitmap(IDB_RING_BITMAP);
	pMemDC->CreateCompatibleDC(pDC);
	CBitmap* OldBitmap = (CBitmap*) pMemDC->SelectObject(pMap);
	m_FromHeight = m_TowerSu;
   while(i <= m_TowerSu )
	 {
		 pDC->BitBlt(70 + ( i * 3), 170 - (10 * i), 70 - (6 * i), 10 , pMemDC, 0, 0, SRCCOPY);
		 m_FromRingList[i].x = 70 + ( i * 3);
		 m_FromRingList[i].y = 170 - (10 * i);
		 m_FromRingList[i].nWidth = 70 - ( 6 * i );
		 m_FromRingList[i].nHeight = 10;
		 m_FromRingList[i].xSrc = 10;
		 m_FromRingList[i].ySrc = 10;
		 i++;	
   }
	delete pMemDC->SelectObject(OldBitmap);
	delete pMemDC;
	ReleaseDC(pDC);
 
	Hanoi(m_TowerSu, 'A', 'C', 'B');//�ϳ��� �˰����� ����
	m_RingPlacecount -= 1;	

}

void CHanoiDlg::RingMove()
{
	Invalidate();
	if(top >= m_RingPlacecount)
		AfxMessageBox("�� �̻� �����ϴ�.");

	if(m_RingPlace[top] == 'A')
	{
		top++;
		if(m_RingPlace[top] == 'B')
		{	
			m_TempHeight++;	
			m_TempRingList[m_TempHeight].x = 220 + (m_TempHeight * 3);
			m_TempRingList[m_TempHeight].y = 170 - ( HEIGHT * m_TempHeight);
			m_TempRingList[m_TempHeight].nWidth = m_FromRingList[m_FromHeight].nWidth;
			m_TempRingList[m_TempHeight].nHeight = 10;
			
			m_FromHeight--;	
		}
		else if(m_RingPlace[top] == 'C')
		{	
			m_ToHeight++;
			m_ToRingList[m_ToHeight].x = 370 + ( m_ToHeight * 3);
			m_ToRingList[m_ToHeight].y = 170 - (HEIGHT * m_ToHeight);
			m_ToRingList[m_ToHeight].nWidth = m_FromRingList[m_FromHeight].nWidth;
			m_ToRingList[m_ToHeight].nHeight = 10;
			m_FromHeight--;
			
		}
		top++;
	}
	else if(m_RingPlace[top] == 'B')
	{
		top++;
		if(m_RingPlace[top] == 'A')
		{
			m_FromHeight++;	
			m_FromRingList[m_FromHeight].x = 70 + ( m_FromHeight * 3);
			m_FromRingList[m_FromHeight].y = 170- ( HEIGHT * m_FromHeight);
			m_FromRingList[m_FromHeight].nWidth = m_TempRingList[m_TempHeight].nWidth;
			m_FromRingList[m_FromHeight].nHeight = 10;
			m_TempHeight--;
		}
		else if(m_RingPlace[top] == 'C')
		{
			m_ToHeight++;
			m_ToRingList[m_ToHeight].x = 370 + ( m_ToHeight * 3);
			m_ToRingList[m_ToHeight].y = 170 - (HEIGHT * m_ToHeight);
			m_ToRingList[m_ToHeight].nWidth = m_TempRingList[m_TempHeight].nWidth;
			m_ToRingList[m_ToHeight].nHeight = 10;
			m_TempHeight--;
		}
		top++;
	}
	else if(m_RingPlace[top] == 'C')
	{
		top++;
		if(m_RingPlace[top] == 'A')
		{
			m_FromHeight++;
			m_FromRingList[m_FromHeight].x = 70 + ( m_FromHeight * 3);
			m_FromRingList[m_FromHeight].y = 170 - ( HEIGHT * m_FromHeight);
			m_FromRingList[m_FromHeight].nWidth = m_ToRingList[m_ToHeight].nWidth;
			m_FromRingList[m_FromHeight].nHeight = 10;
			m_ToHeight--;
			
		}
		else if(m_RingPlace[top] == 'B')
		{
			m_TempHeight++;
			m_TempRingList[m_TempHeight].x = 220 + ( m_TempHeight * 3);
			m_TempRingList[m_TempHeight].y = 170 - ( HEIGHT * m_TempHeight);
			m_TempRingList[m_TempHeight].nWidth = m_ToRingList[m_ToHeight].nWidth;
			m_TempRingList[m_TempHeight].nHeight = 10;
			m_ToHeight--;
			
		}
		top++;
	}
	Invalidate();
}
void CHanoiDlg::DrawMove()
{
		CPaintDC objectDC1(this);
		CDC *pDC=GetDC();
		CDC * pMemDC = new CDC;
		CBitmap* pMap = new CBitmap();
		pMap->LoadBitmap(IDB_RING_BITMAP);
		pMemDC->CreateCompatibleDC(pDC);
		CBitmap* OldBitmap = (CBitmap*) pMemDC->SelectObject(pMap);
		for(int i = m_FromHeight ; i > 0  ; i--)
		{

			pDC->BitBlt(m_FromRingList[i].x, m_FromRingList[i].y , m_FromRingList[i].nWidth, 
				m_FromRingList[i].nHeight ,pMemDC, 0, 0, SRCCOPY);	
		}
		for(int j = m_TempHeight ; j > 0  ; j--)
		{

			pDC->BitBlt(m_TempRingList[j].x, m_TempRingList[j].y , m_TempRingList[j].nWidth, 
				m_TempRingList[j].nHeight ,pMemDC, 0, 0, SRCCOPY);	
		}
		for(int k = m_ToHeight ; k > 0 ; k--)
		{

			pDC->BitBlt(m_ToRingList[k].x, m_ToRingList[k].y , m_ToRingList[k].nWidth, 
				m_ToRingList[k].nHeight ,pMemDC, 0, 0, SRCCOPY);	
		}
		delete pMemDC->SelectObject(OldBitmap);
		delete pMemDC;
		ReleaseDC(pDC);

}
