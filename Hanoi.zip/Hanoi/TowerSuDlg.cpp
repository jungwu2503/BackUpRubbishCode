// TowerSuDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Hanoi.h"
#include "TowerSuDlg.h"
#include "HanoiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTowerSuDlg dialog


CTowerSuDlg::CTowerSuDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTowerSuDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTowerSuDlg)

	m_TowerOfSu  = 0;
	//}}AFX_DATA_INIT
}


void CTowerSuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTowerSuDlg)
	DDX_Text(pDX, IDC_EDIT1, m_TowerOfSu);
	DDV_MinMaxInt(pDX, m_TowerOfSu, 1, 5);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTowerSuDlg, CDialog)
	//{{AFX_MSG_MAP(CTowerSuDlg)
	ON_BN_CLICKED(IDC_OK_BUTTON, OnOkButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTowerSuDlg message handlers


void CTowerSuDlg::OnOkButton() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if( m_TowerOfSu > 0 && m_TowerOfSu < 6 )
	{
	
		CHanoiDlg dlg;
		dlg.DoModal(m_TowerOfSu);
	}

}
