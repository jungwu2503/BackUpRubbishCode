// Rectangle.h: interface for the CRectangle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECTANGLE_H__8E0FEC9F_D49E_4358_95B7_FD3103D1D6CF__INCLUDED_)
#define AFX_RECTANGLE_H__8E0FEC9F_D49E_4358_95B7_FD3103D1D6CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRectangle  
{
public:
	int x1,x2;
	int y1,y2;
	

public:
	void RectangleSizeDecide(int size);
	CRectangle();
	virtual ~CRectangle();

};

#endif // !defined(AFX_RECTANGLE_H__8E0FEC9F_D49E_4358_95B7_FD3103D1D6CF__INCLUDED_)
