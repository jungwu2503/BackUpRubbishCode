// RingList.cpp: implementation of the CRingList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Hanoi.h"
#include "RingList.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRingList::CRingList()
{
	x = 0;
	y = 0;
	nWidth = 0;
	nHeight = 0;
	xSrc = 0;
	ySrc = 0;
}

CRingList::~CRingList()
{

}
