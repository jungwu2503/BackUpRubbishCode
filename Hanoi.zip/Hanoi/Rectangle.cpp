// Rectangle.cpp: implementation of the CRectangle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Hanoi.h"
#include "Rectangle.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#include "TowerSuDlg.h"
#define SIZE 10

CRectangle::CRectangle()
{
	CTowerSuDlg dlg;

}

CRectangle::~CRectangle()
{

}

void CRectangle::RectangleSizeDecide(int size)
{
//	CRect rect;
//	GetClientRect(rect);
	x1 = SIZE *size;
	x2 = SIZE *size;
	y1 = SIZE *size;
	y2 = SIZE *size;



}
