import java.util.*;

// finding the last position of 1 in the array of consecutive 1's
class FindingUpperBoundDriver 
{
	static Random rand = new Random();
	static int leap[] = new int[32];
	static {
		leap[0] = 0;
		leap[1] = 1;
		for(int i = 2; i < leap.length; i++) {
			leap[i] = 2*leap[i-1];
		}
	}
	static void seedData(int x[],int max) {
		for(int i = 0; i < max; i++) {
			x[i] = 1;
		}
		for(int i = max; i < x.length; i++) {
			x[i] = 0;
		}
	}
	static void print(int x[]) {
		for(int i = 0; i < x.length; i++) {
			System.out.printf(x[i] + " ");
		}
		System.out.println();
	}
	static int getArraySize(int n) {
		int base = 2;

		while((n = n/2) > 0) {
			base = base *2;
		}
		return base;
	}
	static void doAsAnimal(int x[]) {
		int nComparison = 0;
		int lastIndex = -1;

		for(int i = 0; i < x.length; i++) {
			nComparison++;
			if (x[i] == 0)
			{
				lastIndex = i-1;
				break;
			}
		}
		System.out.println("===Animal's behavior===");
		System.out.println("# of comparisons = " + nComparison);
		System.out.println("last index of 1 = " + lastIndex);
	}
	public static void main(String[] args) 
	{
		int nData = rand.nextInt(10000000);
		int data[] = new int[100000000];

		seedData(data,nData);
		System.out.println("last position = " + (nData-1));
/////
		int nComparison = 0;
		int i;
		int lastIndex = -1;

		int lower = -1;
		int upper = leap[0];
		int leapCount = 0;
		while(true) {
			if (nComparison < 40)
			{
				System.out.println("at: " + upper + " value: " + data[upper]);
			}
			nComparison++;
			if (data[upper] == 0)
			{
				nComparison++;
				if (leapCount == 1) 
				{
					lastIndex = upper - 1;
					break;
				}
				upper = lower + 1;
				leapCount = 1;
			} else {
				lower = upper;
				leapCount++;
				upper = upper + leap[leapCount];
			}
		}

		System.out.println("data size = " + nData);
		System.out.println("# of comparisons = " + nComparison);
		System.out.println("last index of 1 = " + lastIndex);
/////
		doAsAnimal(data);
	}
}
