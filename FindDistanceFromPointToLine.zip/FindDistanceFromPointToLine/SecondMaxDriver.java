import java.util.*;

class SecondMaxDriver 
{
	static Random rand = new Random();
	static void seedData(int x[],int max) {
		int range;

		for(int i = 0; i < x.length; i++) {
			x[i] = rand.nextInt(max);
		}
	}
	static void print(int x[]) {
		for(int i = 0; i < x.length; i++) {
			if (x.length <= 32)
			{
				System.out.printf("%3d",x[i]);
			}
		}
		if (x.length <= 32) System.out.println();
	}
	static int getArraySize(int n) {
		int base = 2;

		while((n = n/2) > 0) {
			base = base *2;
		}
		return base;
	}
	static void doAsAnimal(int x[]) {
		int nComparison = 0;
		int max = -1;
		int secondMax = -1;

		for(int i = 0; i < x.length; i++) {
			nComparison++;
			if (x[i] >= max)
			{
				secondMax = max;
				max = x[i];
				continue;
			} 
			nComparison++;
			if (x[i] > secondMax)
			{
				secondMax = x[i];
			}
		}
		System.out.println("===Animal's behavior===");
		System.out.println("data size = " + x.length);
		System.out.println("# of comparisons = " + nComparison);
		System.out.println("Max = " + max);
		System.out.println("Second max = " + secondMax);
	}
	public static void main(String[] args) 
	{
		int nData = rand.nextInt(1000000);
//		int nData = 1000000;
//		int nData = 13;
		int nSize = getArraySize(nData);
		int data[] = new int[nData];
		int N = 2*nSize;
		int x[] = new int[N];
		int offset[] = new int[nSize];
		int nComparison = 0;
		int i;

		if (nData <= 32)
		{
			seedData(data,3*nData);
		} else {
			seedData(data,10*nData);
		}

		for(i = 0; i < nSize; i++)
		{
			x[i] = 0;
		}
		for(i = nSize; i < nSize+nData; i++)
		{
			x[i] = data[i-nSize];
		}
		for(i = nData+nSize; i < N; i++) {
			x[i] = -1;
		}
		print(x);
		for(i = N-2; i > 0; i = i-2) {
			nComparison++;
			if (x[i] > x[i+1])
			{
				x[i/2] = x[i];
				offset[i/2] = 0;
			} else {
				x[i/2] = x[i+1];
				offset[i/2] = 1;
			}
			print(x);
		}
		print(offset);

		int iMax = 1;
		int secondMax = -1;
		while(iMax < nSize) {
			int iSecond = 2*iMax + (1-offset[iMax]);
			System.out.println(x[iSecond]);
			iMax = 2*iMax + offset[iMax];
			nComparison++;
			if (x[iSecond] > secondMax)
			{
				secondMax = x[iSecond];
			}
		}
		System.out.println("data size = " + nData);
		System.out.println("# of comparisons = " + nComparison);
		System.out.println("Max = " + x[1]);
		System.out.println("Second max = " + secondMax);

		doAsAnimal(data);
	}
}
