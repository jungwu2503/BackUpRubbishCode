import java.util.*;

// searching data in the array of sorted data of unknown upper bound
class SearchingDataInUnknownUpperBoundDriver 
{
	static Random rand = new Random();
	static int leap[] = new int[32];
	static {
		leap[0] = 0;
		leap[1] = 1;
		for(int i = 2; i < leap.length; i++) {
			leap[i] = 2*leap[i-1];
		}
	}
	static int seedData(int x[]) {
		for(int i = 0; i < x.length; i++) {
			x[i] = 0;
		}
		int n = rand.nextInt(10000000);

		SortedSet aSet = new TreeSet();
		for(int i = 0; i < n; i++) {
			aSet.add(rand.nextInt(n)+1); // avoid generating zero random number
		}

		Object tmp[] = aSet.toArray();
		for(int i = 0; i < tmp.length; i++) {
			x[i] = (int)tmp[i];
		}
		return tmp.length;
	}
	static void print(int x[]) {
		for(int i = 0; i < x.length; i++) {
			System.out.printf(x[i] + " ");
		}
		System.out.println();
	}
	static int getArraySize(int n) {
		int base = 2;

		while((n = n/2) > 0) {
			base = base *2;
		}
		return base;
	}
	static void doAsAnimal(int x[],int dataToFind) {
		// linear search
		int pos = -1;

		long startTime = System.nanoTime();
		for(int i = 0; i < x.length; i++) {
			if (x[i] == dataToFind) {
				pos = i;
				break;
			}
		}
		long stopTime = System.nanoTime();
		System.out.println("===Animal's behavior===");
		System.out.println("time elapsed: " + (stopTime - startTime));
		System.out.println("data to find = " + dataToFind);
		System.out.println("found position = " + pos);
	}
	public static int binarySearch(int x[],int dataToFind,int low,int high) {
					// start binary search
		int mid;
		while(low <= high) {
			mid = (low+high)/2;
			if (dataToFind == x[mid]) {
				return mid;
			} else if (dataToFind > x[mid]) {
				low = mid + 1;
			} else {
				high = mid - 1;
			}
		}
		return -1;
	}
	public static void main(String[] args) 
	{
		long startTime = 0;
		long stopTime = 0;

		int data[] = new int[100000000];

		int nData = seedData(data);
		int pos = rand.nextInt(nData-1);
		int dataToFind = data[pos];

		System.out.println("last position = " + (nData-1));

		dataToFind++;
		if (data[pos+1] == dataToFind)
		{
			pos++;
			System.out.println("data[" + pos + "] = " + dataToFind);
		} else {
			System.out.println("Test No Found!!!");
		}

/////
		startTime = System.nanoTime(); // System.currentTimeMillis() is too rough
		int i;
		int lastIndex = -1;

		int lower = -1;
		int upper = leap[0];
		int leapCount = 0;
		pos = -1; 
		while(true) {
			if (data[upper] == 0)
			{
				if (leapCount == 1) 
				{
					break;
				}
				upper = lower + 1;
				leapCount = 1;
			} else {
				if (dataToFind <= data[upper])
				{
					pos = binarySearch(data,dataToFind,lower,upper);
					break;
				}
				lower = upper;
				leapCount++;
				upper = upper + leap[leapCount];
			}
		}
		stopTime = System.nanoTime();
		System.out.println("time elapsed: " + (stopTime - startTime));
		System.out.println("data to find = " + dataToFind);
		System.out.println("found position = " + pos);
/////
		doAsAnimal(data,dataToFind);
	}
}
