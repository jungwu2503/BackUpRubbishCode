import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import java.util.*;


class TimerPanel extends JPanel implements ActionListener
{
	Timer timer;
	Timer timer2;
	int count = 10;
	Integer list[] = new Integer[10];

	TimerPanel() {
		timer = new Timer(1000,this);
	}
	void start() {
	    timer.start();
	}
    	public void actionPerformed(ActionEvent ev) {
	    repaint();
	    if (count < 0)
	    {
		timer.stop();
	    }
	    System.out.println("HELLO");
	}
	public void paintComponent(Graphics g) {
	    super.paintComponent(g);

	    g.drawString(""+count,50,50);
	    count--;
	}
}
class SwingTimerTest 
{
	public static void main(String[] args) 
	{
	    JFrame f = new JFrame("Timer");
	    TimerPanel p = new TimerPanel();
	    f.getContentPane().add(p,BorderLayout.CENTER);
	    f.setSize(100,100);
	    f.setVisible(true);
	    p.start();
	}
}

/*
	    synchronized(list) {
		    if (count == 5)
		    {
			try
			{
				list.wait(0);
			}
			catch (InterruptedException ex)
			{
			}
		    }
	    }
*/