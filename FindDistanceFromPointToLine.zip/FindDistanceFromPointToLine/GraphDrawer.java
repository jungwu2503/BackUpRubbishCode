import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DrawerPanel extends JPanel implements ActionListener
{  
	static int SX = 50;
	static int SY = 50;
	static int WIDTH = 500;
	static int HEIGHT = 500;
	static int OX = SX + WIDTH/10;
	static int OY = SY + HEIGHT;
	static int XWIDTH = WIDTH + WIDTH/10;
	static int YHEIGHT = HEIGHT + HEIGHT/10;
	static int MARKINGSIZE = 5;

	String ft[] = { "y = x", "y = x^2", "y = x^3", 
					"y = 2^x", "y = 3^x", "y = e^x",
					"y = ln(x)", "y = log3(x)", "y = log2(x)",
					"y = sqrt3(x)", "y = sqrt(x)", "all" };
	Integer domain[] = { 10, 15, 20, 30, 50, 100, 200 };
	Integer range[] = { 10, 100, 1000, 10000, 100000, 1000000, 1000000000 };

	JComboBox functions;
	JComboBox domains;

	int selectedFunction = 0;
	int selectedDomain = 0;

	static double f(double x,int ft) {
		switch(ft) {
			case 0: return x;
			case 1: return x*x;
			case 2: return x*x*x;
			case 3: return Math.pow(2,x);
			case 4: return Math.pow(3,x);
			case 5: return Math.exp(x);
			case 6: return Math.log(x);
			case 7: return Math.log10(x)/Math.log10(3.0);
			case 8: return Math.log10(x)/Math.log10(2.0);
			case 9: return Math.pow(x,1.0/3.0);
			case 10: return Math.sqrt(x);
			default: return x;
		}
	}

	DrawerPanel() {
		setLayout(new BorderLayout());

		JPanel panel = new JPanel();

		panel.add(new JLabel("Function"));
		functions = new JComboBox(ft);
		panel.add(functions);
		functions.addActionListener(this);

		domains = new JComboBox(domain);
		panel.add(domains);
		domains.addActionListener(this);
		panel.add(new JLabel("Domain"));

		add(panel,BorderLayout.SOUTH);
		selectedFunction = 0;
		selectedDomain = 0;
	}
	public void actionPerformed(ActionEvent ev) {
		JComboBox box = (JComboBox)ev.getSource();
		if (box == functions)
		{
			selectedFunction = box.getSelectedIndex();
		} else if (box == domains)
		{
			selectedDomain = box.getSelectedIndex();
		}
		repaint(0,0,getWidth(),getHeight());
	}
	void drawAxes(Graphics g) {
		// draw X axis
		g.drawLine(SX,SY+HEIGHT,SX+XWIDTH,SY+HEIGHT);
		// draw Y axis
		g.drawLine(OX,SY,OX,SY+YHEIGHT);

		// draw interval
		int i;
		int interval = WIDTH/10;
		g.drawLine(OX-interval,OY,OX-interval,OY-MARKINGSIZE);
		g.drawLine(OX,OY+interval,OX+MARKINGSIZE,OY+interval);
		for(i = 1; i <= 10; i++) {
			g.drawLine(OX+i*interval,OY,
				OX+i*interval,OY-MARKINGSIZE);
			g.drawLine(OX,OY-i*interval,
				OX+MARKINGSIZE,OY-i*interval);
		}

		String maxDomain = "" + domain[selectedDomain];
		g.drawString(maxDomain,SX+XWIDTH,SY+HEIGHT-10);
		String maxRange = "" + range[selectedDomain];
		g.drawString(maxRange,OX+10,SY);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		drawAxes(g);

		double maxDomain = (double)domain[selectedDomain];
		double maxRange = (double)range[selectedDomain];
		double delta = (maxDomain+0.1*maxDomain)/XWIDTH;
		
		if (selectedFunction == 11) // all functions
		{
			for (int function = 0; function < selectedFunction; function++)
			{
				if (function == 2) // y = x^3
				{
					g.setColor(Color.red);
				} else if (function == 4) // y = 3^x
				{
					g.setColor(Color.blue);
				} else {
					g.setColor(Color.black);
				}
				double startX = -0.1*maxDomain;
				double startY = f(startX,function);
				int oldX = OX + (int)(startX*WIDTH/maxDomain);
				int oldY = (int)(-(startY*HEIGHT/(maxRange)) + OY);

				double x;
				for(x = -0.1*maxDomain; x < maxDomain; x = x + delta) {
					double y = f(x,function);

					if (y > maxRange) y = maxRange;

					int xPrime = OX + (int)(x*WIDTH/maxDomain);
					int yPrime = (int)(-(y*HEIGHT/(maxRange)) + OY);
					g.drawLine(oldX,oldY,xPrime,yPrime);

					if (y == maxRange) break;

					oldX = xPrime;
					oldY = yPrime;
				}
			}
			// erase log() function side effect
			g.setColor(getBackground());
			g.drawLine(OX,0,OX,SY);
			return;
		}

		double startX = -0.1*maxDomain;
		double startY = f(startX,selectedFunction);
		int oldX = OX + (int)(startX*WIDTH/maxDomain);
		int oldY = (int)(-(startY*HEIGHT/(maxRange)) + OY);

		double x;
		for(x = -0.1*maxDomain; x < maxDomain; x = x + delta) {
			double y = f(x,selectedFunction);

			if (y > maxRange) y = maxRange;

			int xPrime = OX + (int)(x*WIDTH/maxDomain);
			int yPrime = (int)(-(y*HEIGHT/(maxRange)) + OY);
//			g.drawOval(xPrime,yPrime,1,1);
			g.drawLine(oldX,oldY,xPrime,yPrime);

			if (y == maxRange) break;

			oldX = xPrime;
			oldY = yPrime;
		}

		// erase log() function side effect
		g.setColor(getBackground());
		g.drawLine(OX,0,OX,SY);
	}
}
class GraphDrawerFrame extends JFrame
{
	GraphDrawerFrame() 
	{
		setTitle("Complexity Graphs");
		setSize(700,700);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		Container contentPane = this.getContentPane();
		contentPane.add(new DrawerPanel());
	}
}
public class GraphDrawer
{  
    public static void main(String[] args)
	{
		JFrame frame = new GraphDrawerFrame();
		frame.setVisible(true);  
    }
}




