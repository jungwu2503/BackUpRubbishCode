import java.util.*;

class Student implements Comparable
{
    static int NAME = 0;
    static int KOR = 1;
    static int ENG = 2;
    static int TOTAL = 3;
    static int SORTBY = NAME;
    String name;
    int kor;
    int eng;
    int total;
    
    Student(String name, int kor, int eng, int total) {
	this.name = name;
	this.kor = kor;
	this.eng = eng;
	this.total = total;
    }
    public static void sortBy(int what) {
	SORTBY = what;
    }
    public String toString() {
	return name + " : " + total;
    }
    public int compareTo(Object obj) {
//	if (!(obj instanceof Student)) throw IllegalArgumentException();
	Student s = (Student)obj;

	if (SORTBY == KOR)
	{
	    return kor - s.kor;
	} else if (SORTBY == ENG)
	{
	    return eng - s.eng;
	} else if (SORTBY == TOTAL)
	{
	    return total - s.total;
	}

	return name.compareTo(s.name);
    }
}

class SortTest 
{
	public static void main(String[] args) 
	{
	    Student[] st = {
		new Student("aaa", 20, 30, 50),
		new Student("xxx", 30, 40, 70),
		new Student("ppp", 10, 10, 20),
		new Student("bbb", 80, 10, 90),
		new Student("hhh", 40, 20, 60)
	    };
	    display(st);

	    Student.sortBy(Student.NAME);
	    Arrays.sort(st);

	    System.out.println("====");
	    display(st);
	}
	static void display(Student[] st) {
	    for (int i = 0; i < st.length; i++)
	    {
		System.out.println(st[i]);
	    }
	}
}
