import java.util.*;

class MyTimerTask extends TimerTask
{
    MyTimerTask() {
		super();
    }
    public void run() {
		System.out.println("boom");
    }
}

class TimerTest 
{
	public static void main(String[] args) 
	{
		Timer timer = new Timer();

		TimerTask t1 = new MyTimerTask();
		TimerTask t2 = new TimerTask() {
				    public void run() {
					System.out.println("\tBOOM");
				    }			
				};
		TimerTask t3 = new TimerTask() {
				    public void run() {
					t1.cancel(); t2.cancel();
				    }			
				};
		timer.schedule(t1,0,500);
		timer.schedule(t2,2000,2000);
		timer.schedule(t3,5000);
		timer.schedule(new TimerTask() {
				    int times = 5;
				    public void run() {
					System.out.println(times--);
					if (times == 0)
					{
					    timer.cancel();
					}
				    }			
				},5000,500);
	}
}
