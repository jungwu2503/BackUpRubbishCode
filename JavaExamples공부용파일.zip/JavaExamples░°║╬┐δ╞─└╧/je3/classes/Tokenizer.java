/*
 * Copyright (c) 2004 David Flanagan.  All rights reserved.
 * This code is from the book Java Examples in a Nutshell, 3nd Edition.
 * It is provided AS-IS, WITHOUT ANY WARRANTY either expressed or implied.
 * You may study, use, and modify it for any non-commercial purpose,
 * including teaching and use in open-source projects.
 * You may distribute it non-commercially as long as you retain this notice.
 * For a commercial use license, or to purchase the book, 
 * please visit http://www.davidflanagan.com/javaexamples3.
 */
package je3.classes;
import java.io.IOException;

public interface Tokenizer {
    public static final int EOF = -1;
    public static final int SPACE = -2;
    public static final int NUMBER = -3;
    public static final int WORD = -4;
    public static final int KEYWORD = -5;
    public static final int TEXT = -6;
    public static final int BOF = -7;
    public static final int OVERFLOW = -8; // internal buffer overflow

    public Tokenizer skipSpaces(boolean skip);
    public Tokenizer tokenizeSpaces(boolean tokenize);
    public Tokenizer tokenizeNumbers(boolean tokenize);
    public Tokenizer tokenizeWords(boolean tokenize);
    public Tokenizer wordRecognizer(WordRecognizer wordRecognizer);
    public Tokenizer keywords(String[] keywords);
    public Tokenizer trackPosition(boolean track);
    public Tokenizer quotes(String openquotes, String closequotes);
    public Tokenizer maximumTokenLength(int size);

    public static interface WordRecognizer {
	public boolean isWordStart(char c);
	public boolean isWordPart(char c, char firstChar);
    }

    public int tokenType();
    public String tokenText();
    public int tokenKeyword(); 
    public int tokenLine();
    public int tokenColumn();
    public int next() throws IOException;
    public int nextChar() throws IOException;
    public int scan(char delimiter, boolean extendCurrentToken,
		    boolean includeDelimiter, boolean skipDelimiter)
	throws IOException;
    public int scan(String delimiter, boolean matchAll,
		    boolean extendCurrentToken, boolean includeDelimiter,
		    boolean skipDelimiter)
	throws IOException;
}
