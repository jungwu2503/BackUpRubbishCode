//
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
class MinesPanel extends JPanel 
	implements ActionListener, MouseListener
{
	JTextField clockField;
	JTextField countField;
	javax.swing.Timer timer = null;
	boolean startFlag;
	JButton button[][] = new JButton[9][9];
	int mineField[][] = new int[11][11];
	Image bomb;
	int boomX = -1;
	int boomY = -1;
	static Point dir[];
	static { 
		dir = new Point[8];
		for(int i = 0; i < 8; i++) dir[i] = new Point();
		dir[0].x = -1; dir[0].y = -1;
		dir[1].x = 0; dir[1].y = -1;
		dir[2].x = 1; dir[2].y = -1;
		dir[3].x = 1; dir[3].y = 0;
		dir[4].x = 1; dir[4].y = 1;
		dir[5].x = 0; dir[5].y = 1;
		dir[6].x = -1; dir[6].y = 1;
		dir[7].x = -1; dir[7].y = 0;
	}
	MinesPanel(JTextField clockField,JTextField countField) 
	{
		setLayout(new GridLayout(9,9));
		setFont(new Font("Times New Roman",Font.BOLD,14));
		this.clockField = clockField;
		this.countField = countField;

		bomb = Toolkit.getDefaultToolkit().getImage("explosion.gif");
		MediaTracker tracker = new MediaTracker(this);
		tracker.addImage(bomb,0);
		try
		{
			tracker.waitForID(0);
		}
		catch (InterruptedException e)
		{
		}

		resetMineField();

		addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e)
				{
					if (e.getClickCount() >= 2)
					{
						int x = e.getX();
						int y = e.getY();
						Dimension sz = button[0][0].getSize();
						int w = sz.width;
						int h = sz.height;
						int i = y / h;
						int j = x / w;
						int n = mineField[i+1][j+1];
						if (n == -1)
						{
							return;
						}
						ArrayList<JButton> l = getNeighborButtonsVisible(i,j);
						if (n == l.size())
						{
							return;
						}
						int nChecked = 0;
						for(int p = 0; p < l.size(); p++) {
							JButton b = l.get(p);
							if (b.getIcon() != null)
							{
								nChecked++;
							}
						}
						if (n != nChecked)
						{
							return;
						}
						for(int p = 0; p < l.size(); p++) {
							JButton b = l.get(p);
							Icon icon = b.getIcon();
							Point pos = getButtonPosition(b);
							int bx = pos.x;
							int by = pos.y;
							if (icon == null && mineField[bx+1][by+1] != -1)
							{
								showButton(bx,by);
							} else if (icon == null && mineField[bx+1][by+1] == -1)
							{
								boomX = bx+1;
								boomY = by+1;
								boom(); 
								return;
							}
						}
						if (succeed())
						{
							doSuccessCeremony();
						}
					}
				}
			}
		);
	}
	private ArrayList<JButton> getNeighborButtonsVisible(int i,int j)
	{
		ArrayList<JButton> l = new ArrayList<JButton>();
		for(int index = 0; index < 8; index++) {
			int x = i+dir[index].x;
			int y = j+dir[index].y;
			if (x != -1 && x != 9 && y != -1 && y != 9)
			{
				if (button[x][y].isVisible())
				{
					l.add(button[x][y]);
				} 
			}
		}
		return l;
	}
	void resetMineField()
	{
		startFlag = true;
		boomX = -1;
		boomY = -1;
		clockField.setText("0");
		countField.setText("10");
		if (timer != null)
		{
			timer.stop();
		}
		if (button[0][0] == null)
		{
			for(int i = 0; i < 9; i++) {
				for(int j = 0; j < 9; j++) {
					add(button[i][j] = new JButton());
					button[i][j].addActionListener(this);
					button[i][j].addMouseListener(this);
				}
			}
		} else {
			for(int i = 0; i < 9; i++) {
				for(int j = 0; j < 9; j++) {
					button[i][j].setVisible(true);
					button[i][j].setIcon(null);
				}
			}
		}
		for(int i = 0; i < 11; i++) {
			for(int j = 0; j < 11; j++) {
				mineField[i][j] = 0;
			}
		}
		ArrayList<Point> l = new ArrayList<Point>();
		while (l.size() < 10)
		{
			double r = Math.random();
			int xPos = (int)(r*1000.0) % 9;
			r = Math.random();
			int yPos = (int)(r*1000.0) % 9;
			Point p = new Point(xPos,yPos);
			if (l.contains(p) == false)
			{
				l.add(p);
			}
		}
		for(int i = 0; i < 10; i++) {
			Point p = l.get(i);
			int xPos = p.x;
			int yPos = p.y;
			mineField[xPos+1][yPos+1] = -1;
		}
		for(int i = 1; i < 10; i++) {
			for(int j = 1; j < 10; j++) {
				if (mineField[i][j] != -1)
				{
					mineField[i][j] = getMineCount(i,j);
				}
			}
		}
	}
	private int getMineCount(int i,int j)
	{
		int n = 0;
		for(int k = 0; k < 8; k++) {
			if (mineField[i+dir[k].x][j+dir[k].y] == -1)
			{
				n++;
			}
		}
		return n;
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Dimension sz = button[0][0].getSize();
		int w = sz.width;
		int h = sz.height;
		for(int i = 0; i <= 9; i++) {
			g.drawLine(i*w,0,i*w,9*h);
		}
		for(int i = 0; i <= 9; i++) {
			g.drawLine(0,i*h,9*w,i*h);
		}
		for(int i = 1; i < 10; i++) {
			for(int j = 1; j < 10; j++) {
				int s = mineField[i][j];
				if (s > 0)
				{
					switch (s)
					{
						case 1: g.setColor(Color.blue); break;
						case 2: g.setColor(Color.gray); break;
						case 3: g.setColor(Color.red); break;
						case 4: g.setColor(Color.pink); break;
						case 5: g.setColor(Color.green); break;
						case 6: g.setColor(Color.lightGray); break;
						case 7: g.setColor(Color.yellow); break;
						case 8: g.setColor(Color.black); break;					
					}
					g.drawString(""+s,(j-1)*w+14,(i-1)*h+20);
				} else if (s < 0)
				{
					if (boomX != -1)
					{
						g.setColor(Color.red);
						g.drawRect((boomY-1)*w+1,(boomX-1)*h+1,w-2,h-2);
						g.setColor(Color.pink);
						g.drawRect((boomY-1)*w+2,(boomX-1)*h+2,w-4,h-4);
						g.setColor(Color.yellow);
						g.drawRect((boomY-1)*w+3,(boomX-1)*h+3,w-6,h-6);
					}
					g.drawImage(bomb,(j-1)*w+4,(i-1)*h+2,this);
				}
			}
		}
	}
	private Point getButtonPosition(JButton b)
	{
		Point pos = new Point();
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				if (button[i][j] == b)
				{
					pos.x = i;
					pos.y = j;
					return pos;
				}
			}
		}
		return null;
	}
	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();
		if (!(source instanceof JButton))
		{
			return;
		}
		if (startFlag)
		{
			startFlag = false;
			
			ActionListener taskPerformer = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int second = Integer.parseInt(clockField.getText());
					second++;
					clockField.setText(""+second);
				}
			};
			timer = new javax.swing.Timer(1000,taskPerformer);
			timer.start();
		}
		JButton b = (JButton)source;
		Point pos = getButtonPosition(b);
		int x = pos.x;
		int y = pos.y;
		if (mineField[x+1][y+1] == -1)
		{
			boomX = x+1;
			boomY = y+1;
			boom();
		} else { 
			showButton(x,y);
			if (succeed())
			{
				doSuccessCeremony();
			}
		}
	}
	private void doSuccessCeremony()
	{
		countField.setText("0");
		if (timer != null)
		{
			timer.stop();
		}
		JOptionPane.showMessageDialog(this,
			"Congratulation!\nYou made it in "+clockField.getText()+" seconds");
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				button[i][j].setVisible(false);
			}
		}
	}
	private boolean succeed()
	{
		int buttonsVisible = 0;
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				if (button[i][j].isVisible())
				{
					buttonsVisible++;
				}
			}
		}
		if (buttonsVisible != 10)
		{
			return false;
		}
		return true;
	}
	private void showButton(int buttonX,int buttonY)
	{
		boolean visited[][] = new boolean[11][11];
		for(int i = 0; i < 11; i++) {
			for(int j = 0; j < 11; j++) {
				if (i == 0 || i == 10 || j == 0 || j == 10)
				{
					visited[i][j] = true;
				} else
					visited[i][j] = false;
			}
		}
		showYourself(buttonX+1,buttonY+1,visited);
	}
	private void showYourself(int x,int y,boolean v[][])
	{
		if (mineField[x][y] == -1) return;
		if (v[x][y] == true) return;
		button[x-1][y-1].setVisible(false);
		v[x][y] = true;
		if (mineField[x][y] > 0) return;
		for(int i = 0; i < 8; i++) {
			showYourself(x+dir[i].x,y+dir[i].y,v);
		}
	}
	private void boom()
	{
		if (timer != null)
		{
			timer.stop();
		}
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				button[i][j].setVisible(false);
			}
		}
		JOptionPane.showMessageDialog(this,"BOOM!\nYou are dead!");
	}
	private boolean ifAllCheckedCorrectly()
	{
		int answerCount = 0;
		for(int i = 0; i < 9; i++) {
			for(int j = 0; j < 9; j++) {
				if (button[i][j].isVisible() && button[i][j].getIcon() != null && mineField[i+1][j+1] == -1)
				{
					answerCount++;
				}
			}
		}
		if (answerCount == 10)
		{
			return true;
		}
		return false;
	}
	public void mousePressed(MouseEvent e)
	{
		Object source = e.getSource();
		if (source instanceof JButton)
		{
			JButton button = (JButton)source;
			if (e.getButton() == MouseEvent.BUTTON3)
			{
				int count = Integer.parseInt(countField.getText());
				if (button.getIcon() == null)
				{
					button.setIcon(new ImageIcon("flag.gif"));
					count--;
					countField.setText(""+count);
				} else {
					button.setIcon(null);
					count++;
					countField.setText(""+count);
				}
				if (count == 0 && ifAllCheckedCorrectly())
				{
					doSuccessCeremony();
					return;
				}
				if (succeed())
				{
					doSuccessCeremony();
				}
			}
		}
	}
	public void mouseClicked(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
};
class ClockStatePanel extends JPanel
{
	private JLabel clockLabel;
	private JTextField clockField;
	ClockStatePanel()
	{
		clockLabel = new JLabel(new ImageIcon("clock.gif"));
		clockField = new JTextField("0",3);
		clockField.setPreferredSize(new Dimension(50,30));
		clockField.setHorizontalAlignment(JTextField.CENTER);
		clockField.setEditable(false);
		clockField.setBorder(BorderFactory.createLoweredBevelBorder());
		clockField.setFont(new Font("SansSerif",Font.BOLD,18));
		clockField.setBackground(Color.lightGray);
		add(clockLabel);
		add(clockField);
	}
	JTextField getClockField()
	{
		return clockField;
	}
};
class CountStatePanel extends JPanel
{
	private JTextField countField;
	private JLabel mineLabel;
	CountStatePanel()
	{
		countField = new JTextField("10",3);
		countField.setPreferredSize(new Dimension(50,30));
		countField.setHorizontalAlignment(JTextField.CENTER);
		countField.setEditable(false);
		countField.setBorder(BorderFactory.createLoweredBevelBorder());
		countField.setFont(new Font("SansSerif",Font.BOLD,18));
		countField.setBackground(Color.lightGray);
		mineLabel = new JLabel(new ImageIcon("mine.gif"));
		add(countField);
		add(mineLabel);
	}
	JTextField getCountField()
	{
		return countField;
	}
};
class StatePanel extends JPanel
{
	private ClockStatePanel clockStatePanel;
	private CountStatePanel countStatePanel;
	StatePanel() 
	{
		setLayout(new GridLayout(1,2));
		clockStatePanel = new ClockStatePanel();
		countStatePanel = new CountStatePanel();
		add(clockStatePanel);
		add(countStatePanel);
	}
	JTextField getCountField()
	{
		return countStatePanel.getCountField();
	}
	JTextField getClockField()
	{
		return clockStatePanel.getClockField();
	}
};
class MinesFrame extends JFrame
{
	private Image mineImage;
	Container contentPane;
	MinesPanel mainPanel;
	StatePanel statePanel;
	MinesFrame()
	{
		setTitle("����ã��");
		setSize(296,350);
		setLocation(100,100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mineImage = Toolkit.getDefaultToolkit().getImage("mineTitle.gif");
		MediaTracker tracker = new MediaTracker(this);
		tracker.addImage(mineImage,0);
		try
		{
			tracker.waitForID(0);
		}
		catch (InterruptedException e)
		{
		}
		setIconImage(mineImage);
		contentPane = getContentPane();
		statePanel = new StatePanel();
		mainPanel = new MinesPanel(statePanel.getClockField(),statePanel.getCountField());
		contentPane.add(mainPanel,"Center");
		contentPane.add(statePanel,"South");
		setMainMenu();
	}
	private void startGame()
	{
		mainPanel.resetMineField();
	}
	private void setMainMenu()
	{
		JMenuBar menuBar = new JMenuBar();
		JMenu gameMenu = new JMenu("Game");
		gameMenu.setMnemonic('G');
		JMenuItem newGame = new JMenuItem("New Game");
		newGame.setMnemonic('N');
		newGame.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2,0));
		newGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				startGame();
			}
		});
		gameMenu.add(newGame);
		gameMenu.add(new JSeparator());
		JMenuItem exit = new JMenuItem("Exit");
		exit.setMnemonic('E');
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		});
		gameMenu.add(exit);
		menuBar.add(gameMenu);

		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');
		JMenuItem information = new JMenuItem("Information");
		information.setMnemonic('I');
		information.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(contentPane,
					"Mines Game\nWritten by Kim\n10/10/2010");
			}
		});
		helpMenu.add(information);
		menuBar.add(helpMenu);

		setJMenuBar(menuBar);
	}
};
class MinesGame 
{
	public static void main(String[] args) 
	{
		JFrame frame = new MinesFrame();
		frame.setResizable(false);
		frame.setVisible(true);
	}
}
