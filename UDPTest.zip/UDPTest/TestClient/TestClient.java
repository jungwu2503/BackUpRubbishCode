import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

class ButtonPanel extends JPanel
{
	MainPanel clientWnd;
	JTextField ip;
	ButtonPanel(MainPanel clientWnd) {
		this.clientWnd = clientWnd;

		ip = new JTextField(15);
		ip.setText("localhost");

		add(ip);
	}
	String getIpAddress() {
		return ip.getText();
	}
}
class InputListener extends KeyAdapter
{
	MainPanel clientWnd;
	JTextField textInput;
	InputListener(JTextField textInput,MainPanel clientWnd) {
		this.clientWnd = clientWnd;
		this.textInput = textInput;
	}
	public void keyPressed(KeyEvent ev) {
		int keyCode = ev.getKeyCode();
		if (keyCode == KeyEvent.VK_ENTER)
		{
			String msg = textInput.getText().trim();
			clientWnd.writeText("[I say] " + msg);
			clientWnd.sendLine(msg);
			textInput.setText("");
		}
	}
}
class ReportPanel extends JPanel
{
	MainPanel clientWnd;
	JTextField reportText;
	JButton reportButton;
	JButton queryButton;
	ReportPanel(MainPanel clientWnd) {
		this.clientWnd = clientWnd;

		reportText = new JTextField(15);
		reportButton = new JButton("Report");
		queryButton = new JButton("Query");

		add(reportText);
		add(reportButton);
		add(queryButton);

		reportButton.addActionListener(clientWnd);
		queryButton.addActionListener(clientWnd);
	}
	String getReportText() {
		return reportText.getText();
	}
}
class InputPanel extends JPanel
{
	MainPanel clientWnd;
	JTextField textInput;
	ReportPanel reportPanel;
	InputPanel(MainPanel clientWnd) {
		this.clientWnd = clientWnd;
		setLayout(new GridLayout(2,1));

		textInput = new JTextField();
		textInput.addKeyListener(new InputListener(textInput,clientWnd));
		reportPanel = new ReportPanel(clientWnd);

		add(textInput);
		add(reportPanel);
	}
	String getReportText() {
		return reportPanel.getReportText();
	}
}

class ListenerFromServer extends Thread
{
	MainPanel wnd;

	public ListenerFromServer(MainPanel clientWnd) {
		this.wnd = clientWnd;
	}

	public void run() {
	    try
	    {
		DatagramSocket listenerSocket = new DatagramSocket(8000);
		
		byte[] buffer = new byte[2048];
		DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
		
		while (true)
		{
		    System.out.println("111");
		    listenerSocket.receive(packet);
		    System.out.println("222");
		    String msg = new String(buffer, 0, packet.getLength(), "UTF-8");
		    wnd.writeText(msg);
		}
	    }
	    catch (Exception e)
	    {
	    }		
	}
}

class MainPanel extends JPanel implements ActionListener
{
	String ipAddress = "localhosr";
	Thread chatThread;

	ButtonPanel buttonPanel;
	InputPanel inputPanel;
	JTextArea textBox;
	JScrollPane textPane;
	MainPanel() {
		buttonPanel = new ButtonPanel(this);
		setLayout(new BorderLayout());

		textBox = new JTextArea();
		textPane = new JScrollPane(textBox);
		textBox.setBorder(BorderFactory.createLoweredBevelBorder());
		inputPanel = new InputPanel(this);

		add(buttonPanel,BorderLayout.NORTH);
		add(textPane,BorderLayout.CENTER);
		add(inputPanel,BorderLayout.SOUTH);

		ListenerFromServer l = new ListenerFromServer(this);
		l.start();
	}
	public void writeText(String msg) {
		textBox.append(msg + "\r\n");
	}
	public void sendLine(String msg) {
		try
		{
			String ipAddress = buttonPanel.getIpAddress();
			InetAddress address = InetAddress.getByName(ipAddress);

			String s = "3 " + msg;

			byte[] message = s.getBytes("UTF-8");

			DatagramPacket packet = new DatagramPacket(message, message.length, address, 7000);

			DatagramSocket dsocket = new DatagramSocket();
			dsocket.send(packet);
			dsocket.close();
		}
		catch (Exception e)
		{
		}
		
	}
	public void actionPerformed(ActionEvent ev) {
		String cmd = ev.getActionCommand();
		String ipAddress = buttonPanel.getIpAddress();
		if (cmd.equals("Report"))
		{
			try
			{			
				writeText("Reporting...");
				
				String host = buttonPanel.getIpAddress();
				InetAddress address = InetAddress.getByName(host);

				String s = "1 " + inputPanel.getReportText();

				byte[] message;

				message = s.getBytes("UTF-8");

				DatagramPacket packet = new DatagramPacket(message, message.length, address, 7000);

				DatagramSocket dsocket = new DatagramSocket();
				dsocket.send(packet);
				dsocket.close();
			}
			catch (IOException ex)
			{
				System.out.println(ex);
			}
		} else if (cmd.equals("Query"))
		{
			try
			{
				writeText("Asking...");
				
				String host = buttonPanel.getIpAddress();
				InetAddress address = InetAddress.getByName(host);

				String s = "2 ";

				byte[] message;

				message = s.getBytes("UTF-8");

				DatagramPacket packet = new DatagramPacket(message, message.length, address, 7000);

				DatagramSocket dsocket = new DatagramSocket();
				dsocket.send(packet);
				dsocket.close();
			}
			catch (IOException ex)
			{
				System.out.println(ex);
			}
		}
	}
}
class ClientFrame extends JFrame
{
	ClientFrame() {
		super("Client");
		setSize(400,600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		contentPane.add(new MainPanel());
	}
}
class TestClient 
{
	public static void main(String[] args) 
	{
		ClientFrame clientFrame = new ClientFrame();
		clientFrame.setVisible(true);
	}
}
