import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

class ServerRole extends Thread
{
	MainPanel wnd;

	public ServerRole(MainPanel serverWnd) {
		this.wnd = serverWnd;
	}
	public void run()
	{
		try
		{
			DatagramSocket listenerSocket = new DatagramSocket(7000);
			wnd.writeText("Server started...");
			wnd.writeText(wnd.myIP + " on port: 7000");

			byte[] buffer = new byte[2048];
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

			while(true) {
				listenerSocket.receive(packet);
				
				String ip = packet.getAddress().getHostName();
				wnd.writeText(ip + " is connected...");
				wnd.addComboBoxItem(ip);

				String msg = new String(buffer, 0, packet.getLength(), "UTF-8");

				StringTokenizer st = new StringTokenizer(msg);

				String s = st.nextToken();

				if (s.equals("1")) // report
				{
				    s = st.nextToken();
				    wnd.writeText("[" + ip + "] " + "report..." + s + " Won");
				    
				    String reportMessage = "[Server says] Thanks!";
				    byte[] message = reportMessage.getBytes("UTF-8");
				    DatagramPacket dpacket = new DatagramPacket(message, message.length,
										packet.getAddress(), 8000);
				    DatagramSocket dsocket = new DatagramSocket();
				    dsocket.send(dpacket);
				    dsocket.close();
				} else if (s.equals("2")) // query
				{
				    wnd.writeText("[" + ip + "] " + "asked...");
				    
				    String queryMessage = "[Server says] " + (int)(Math.random()*10);
				    byte[] message = queryMessage.getBytes("UTF-8");
				    DatagramPacket dpacket = new DatagramPacket(message, message.length,
										packet.getAddress(), 8000);
				    DatagramSocket dsocket = new DatagramSocket();
				    dsocket.send(dpacket);
				    dsocket.close();
				} else if (s.equals("3")) // chat
				{
				    String message = st.nextToken();
				    wnd.writeText("[" + ip + "] " + "says..." + message);			
				}
				
				packet.setLength(buffer.length);
			}
		}
		catch (IOException ex)
		{
			System.out.println(ex);
		}
	}
	public void sendLine(String ip,String msg)
	{
		
	}
}

class ButtonPanel extends JPanel
{
	MainPanel serverWnd;
	JButton startButton;
	JButton stopButton;
	JButton salesRecordButton;
	ButtonPanel(MainPanel serverWnd) {
		this.serverWnd = serverWnd;

		startButton = new JButton("Start");
		stopButton = new JButton("Stop");
		salesRecordButton = new JButton("Sales Record");

		add(startButton);
		add(stopButton);
		add(salesRecordButton);

		startButton.addActionListener(serverWnd);
		stopButton.addActionListener(serverWnd);
		salesRecordButton.addActionListener(serverWnd);
	}
}
class InputListener extends KeyAdapter
{
	MainPanel serverWnd;
	JTextField textInput;
	InputListener(JTextField textInput,MainPanel serverWnd) {
		this.serverWnd = serverWnd;
		this.textInput = textInput;
	}
	public void keyPressed(KeyEvent ev) {
		int keyCode = ev.getKeyCode();
		if (keyCode == KeyEvent.VK_ENTER)
		{
			String msg = textInput.getText().trim();
			serverWnd.writeText("[I say ] " + msg);
			String clientIP = serverWnd.getSelectedIP();
			serverWnd.sendLine(clientIP,msg);
			textInput.setText("");
		}
	}
}
class InputPanel extends JPanel
{
	MainPanel serverWnd;
	JComboBox<String> ips;
	JTextField textInput;
	InputPanel(MainPanel serverWnd) {
		this.serverWnd = serverWnd;
		setLayout(new GridLayout(2,1));

		ips = new JComboBox<String>();
		textInput = new JTextField();
		textInput.addKeyListener(new InputListener(textInput,serverWnd));

		add(ips);
		add(textInput);
	}
	public void addComboBoxItem(String ip) {
		int n;
		
		ips.removeItem(ip);
		ips.insertItemAt(ip,0);
		ips.setSelectedIndex(0);
	}
	String getSelectedIP() {
		return ips.getItemAt(ips.getSelectedIndex());
	}
}
class MainPanel extends JPanel implements ActionListener
{
	ButtonPanel buttonPanel;
	JTextArea textBox;
	JScrollPane textPane;
	InputPanel inputPanel;
	ServerRole server;
	String myIP;

	MainPanel() {
		buttonPanel = new ButtonPanel(this);
		setLayout(new BorderLayout());

		textBox = new JTextArea();
		textPane = new JScrollPane(textBox);
		textBox.setBorder(BorderFactory.createLoweredBevelBorder());
		inputPanel = new InputPanel(this);

		add(buttonPanel,BorderLayout.NORTH);
		add(textPane,BorderLayout.CENTER);
		add(inputPanel,BorderLayout.SOUTH);
		writeText("Please press start button");

		try
		{
			InetAddress address = InetAddress.getLocalHost();
			myIP = address.getHostAddress();
		}
		catch (Exception ex)
		{
		}
	}
	String getSelectedIP() {
		return inputPanel.getSelectedIP();
	}
	void sendLine(String ip,String msg) {
		try
		{
			InetAddress address = InetAddress.getByName(ip);

			String s = "[Server says] " + msg;
				
			byte[] message = s.getBytes("UTF-8");

			DatagramPacket packet = new DatagramPacket(message, message.length, address, 8000);

			DatagramSocket dsocket = new DatagramSocket();
			dsocket.send(packet);
			dsocket.close();
		}
		catch (Exception e)
		{
		}
	}
	public void addComboBoxItem(String ip) {
		inputPanel.addComboBoxItem(ip);
	}
	public void writeText(String msg) {
		textBox.append(msg + "\r\n");
	}
	public void actionPerformed(ActionEvent ev) {
		String command = ev.getActionCommand();
		if (command.equals("Start"))
		{
			server = new ServerRole(this);
			server.start();
		} else if (command.equals("Stop"))
		{
			server.stop();
		}
	}
}
class ServerFrame extends JFrame
{
	ServerFrame() {
		super("Server");
		setSize(400,600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Container contentPane = getContentPane();
		contentPane.add(new MainPanel());
	}
}
class TestServer 
{
	public static void main(String[] args) 
	{
		ServerFrame serverFrame = new ServerFrame();
		serverFrame.setVisible(true);
	}
}
